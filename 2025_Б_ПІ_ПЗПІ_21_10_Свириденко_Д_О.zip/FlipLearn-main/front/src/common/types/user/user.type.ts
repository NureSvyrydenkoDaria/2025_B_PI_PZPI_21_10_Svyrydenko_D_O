export interface User {
  id: string;
}
