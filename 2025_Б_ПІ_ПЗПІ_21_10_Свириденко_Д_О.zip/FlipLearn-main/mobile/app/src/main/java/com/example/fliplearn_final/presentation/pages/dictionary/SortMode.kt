package com.example.fliplearn_final.presentation.pages.dictionary

enum class SortMode {
    TERM, MEANING, TRANSLATION
}