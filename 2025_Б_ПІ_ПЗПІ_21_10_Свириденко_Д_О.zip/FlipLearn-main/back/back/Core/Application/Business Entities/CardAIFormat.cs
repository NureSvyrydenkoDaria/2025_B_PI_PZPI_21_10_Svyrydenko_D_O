﻿namespace back.Core.Application.Business_Entities
{
    public class CardAIFormat
    {
        public string Word { get; set; }
        public string? Definition { get; set; }
        public string? Translation { get; set; }
    }
}
