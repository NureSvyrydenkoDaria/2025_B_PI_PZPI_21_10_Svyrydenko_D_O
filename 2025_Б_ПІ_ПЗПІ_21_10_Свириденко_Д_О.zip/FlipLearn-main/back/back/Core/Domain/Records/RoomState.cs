﻿namespace back.Core.Domain.Records
{
    public enum RoomState : byte
    {
        Forming = 1,
        InRace = 2,
        Finished = 3
    }
}
