﻿namespace back.Core.Domain.Records
{
    public record class AccessData(int userId, string access);
}
