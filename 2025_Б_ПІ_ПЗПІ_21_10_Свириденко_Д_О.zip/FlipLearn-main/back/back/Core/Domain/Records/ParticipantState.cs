﻿namespace back.Core.Domain.Records
{
    
    public enum ParticipantState : byte
    {
        WaitingForRace = 1,
        InRace = 2,
        Finished = 3
    }
}
