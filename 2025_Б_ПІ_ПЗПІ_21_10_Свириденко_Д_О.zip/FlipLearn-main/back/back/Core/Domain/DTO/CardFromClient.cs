﻿namespace back.Core.Domain.DTO
{
    public class CardFromClient
    {
        public string Term { get; set; }
        public string? Meaning { get; set; }
        public string? Translation { get; set; }
    }
}